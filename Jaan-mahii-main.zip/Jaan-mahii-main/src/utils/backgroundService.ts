// Background Execution & Screen Wake Lock Utility

export interface BackgroundServiceOptions {
  onScreenOn?: (offDurationSeconds: number) => void;
  onScreenOff?: () => void;
}

class BackgroundService {
  private wakeLock: any = null;
  private silentAudio: HTMLAudioElement | null = null;
  private lastHiddenTime: number | null = null;
  private isEnabled: boolean = true;
  private onScreenOnCallback: ((offDurationSeconds: number) => void) | null = null;
  private onScreenOffCallback: (() => void) | null = null;

  public init(options: BackgroundServiceOptions) {
    this.onScreenOnCallback = options.onScreenOn || null;
    this.onScreenOffCallback = options.onScreenOff || null;

    if (typeof window === 'undefined') return;

    // Listen to visibility change (Screen Off / Screen On / Tab switch)
    document.addEventListener('visibilitychange', this.handleVisibilityChange);
    window.addEventListener('focus', this.handleWindowFocus);

    // Setup MediaSession API
    this.setupMediaSession();

    // Initial wake lock request if supported
    this.requestWakeLock();
  }

  public setEnabled(enabled: boolean) {
    this.isEnabled = enabled;
    if (enabled) {
      this.requestWakeLock();
      this.startSilentAudioKeepAlive();
    } else {
      this.releaseWakeLock();
      this.stopSilentAudioKeepAlive();
    }
  }

  // Request Web Screen Wake Lock
  public async requestWakeLock(): Promise<boolean> {
    if (!this.isEnabled) return false;
    if (typeof navigator !== 'undefined' && 'wakeLock' in navigator) {
      try {
        this.wakeLock = await (navigator as any).wakeLock.request('screen');
        console.log('[BackgroundService] Screen Wake Lock acquired');
        
        this.wakeLock.addEventListener('release', () => {
          console.log('[BackgroundService] Screen Wake Lock released');
          this.wakeLock = null;
        });
        return true;
      } catch (err) {
        console.warn('[BackgroundService] Wake lock error:', err);
      }
    }
    return false;
  }

  public releaseWakeLock() {
    if (this.wakeLock) {
      try {
        this.wakeLock.release();
      } catch {}
      this.wakeLock = null;
    }
  }

  // Start silent audio keep-alive to keep Web Audio & WebSocket background connections active
  public startSilentAudioKeepAlive() {
    if (this.silentAudio) return;

    try {
      // 1-second clean silent wav data URI
      const silentWavBase64 =
        'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=';
      const audio = new Audio(silentWavBase64);
      audio.loop = true;
      audio.volume = 0.01;
      
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            this.silentAudio = audio;
            console.log('[BackgroundService] Silent Audio Keep-Alive active');
          })
          .catch((e) => {
            console.warn('[BackgroundService] Silent audio play blocked until user gesture:', e);
          });
      }
    } catch (e) {
      console.warn('[BackgroundService] Silent audio keep-alive failed:', e);
    }
  }

  public stopSilentAudioKeepAlive() {
    if (this.silentAudio) {
      try {
        this.silentAudio.pause();
        this.silentAudio.src = '';
      } catch {}
      this.silentAudio = null;
    }
  }

  // MediaSession integration for Lock Screen / Notification controls
  public setupMediaSession() {
    if (typeof navigator !== 'undefined' && 'mediaSession' in navigator) {
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: 'Mahii AI Girlfriend',
          artist: 'Sassy & Loving Voice Companion',
          album: 'Background Voice Engine Active',
          artwork: [
            { src: '/icon.svg', sizes: '192x192', type: 'image/svg+xml' },
            { src: '/icon.svg', sizes: '512x512', type: 'image/svg+xml' },
          ],
        });

        navigator.mediaSession.setActionHandler('play', () => {
          console.log('[MediaSession] Play triggered');
        });
        navigator.mediaSession.setActionHandler('pause', () => {
          console.log('[MediaSession] Pause triggered');
        });
      } catch (err) {
        console.warn('[BackgroundService] MediaSession setup error:', err);
      }
    }
  }

  private handleVisibilityChange = () => {
    if (document.visibilityState === 'hidden') {
      this.lastHiddenTime = Date.now();
      if (this.onScreenOffCallback) {
        this.onScreenOffCallback();
      }
    } else if (document.visibilityState === 'visible') {
      // Screen turned on or tab became visible
      this.reacquireAndNotify();
    }
  };

  private handleWindowFocus = () => {
    if (document.visibilityState === 'visible') {
      this.reacquireAndNotify();
    }
  };

  private reacquireAndNotify = () => {
    // Reacquire wake lock when coming back to foreground
    this.requestWakeLock();

    if (this.lastHiddenTime) {
      const durationSeconds = Math.round((Date.now() - this.lastHiddenTime) / 1000);
      this.lastHiddenTime = null;

      // Trigger Screen-On callback if screen was off for more than 2 seconds
      if (durationSeconds >= 2 && this.onScreenOnCallback) {
        console.log(`[BackgroundService] Screen turned ON! Screen was off for ${durationSeconds}s`);
        this.onScreenOnCallback(durationSeconds);
      }
    }
  };

  public isWakeLockActive(): boolean {
    return !!this.wakeLock;
  }

  public destroy() {
    if (typeof window === 'undefined') return;
    document.removeEventListener('visibilitychange', this.handleVisibilityChange);
    window.removeEventListener('focus', this.handleWindowFocus);
    this.releaseWakeLock();
    this.stopSilentAudioKeepAlive();
  }
}

export const backgroundService = new BackgroundService();
