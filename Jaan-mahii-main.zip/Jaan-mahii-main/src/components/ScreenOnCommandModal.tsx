import React, { useEffect, useState } from 'react';
import {
  Smartphone,
  Mic,
  Zap,
  Volume2,
  Flashlight,
  Music,
  Clock,
  Phone,
  MessageSquare,
  X,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Radio,
  MapPin,
  Play
} from 'lucide-react';

interface ScreenOnCommandModalProps {
  isOpen: boolean;
  onClose: () => void;
  screenOffDurationSeconds: number;
  onRunCommand: (commandText: string) => void;
  onStartVoiceCommand: () => void;
  backgroundActive: boolean;
  wakeLockActive: boolean;
}

export const ScreenOnCommandModal: React.FC<ScreenOnCommandModalProps> = ({
  isOpen,
  onClose,
  screenOffDurationSeconds,
  onRunCommand,
  onStartVoiceCommand,
  backgroundActive,
  wakeLockActive,
}) => {
  const [countdown, setCountdown] = useState<number>(10);

  useEffect(() => {
    if (!isOpen) return;
    setCountdown(10);
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const quickCommands = [
    {
      id: 'torch',
      label: 'Turn Flashlight ON',
      text: 'Mahii, turn on the flashlight',
      icon: <Flashlight className="w-4 h-4 text-amber-400" />,
      color: 'hover:border-amber-500/50 hover:bg-amber-500/10 text-amber-300',
    },
    {
      id: 'spotify',
      label: 'Play Romantic Music',
      text: 'Mahii, play some sweet romantic songs on Spotify',
      icon: <Music className="w-4 h-4 text-emerald-400" />,
      color: 'hover:border-emerald-500/50 hover:bg-emerald-500/10 text-emerald-300',
    },
    {
      id: 'alarm',
      label: 'Set 5 Min Timer',
      text: 'Mahii, set a timer for 5 minutes',
      icon: <Clock className="w-4 h-4 text-cyan-400" />,
      color: 'hover:border-cyan-500/50 hover:bg-cyan-500/10 text-cyan-300',
    },
    {
      id: 'call',
      label: 'Talk to Mahii',
      text: 'Hii Mahii babu, I unlocked my screen to talk to you!',
      icon: <Phone className="w-4 h-4 text-pink-400" />,
      color: 'hover:border-pink-500/50 hover:bg-pink-500/10 text-pink-300',
    },
    {
      id: 'status',
      label: 'What did I miss?',
      text: 'Mahii, what happened while my screen was off?',
      icon: <MessageSquare className="w-4 h-4 text-purple-400" />,
      color: 'hover:border-purple-500/50 hover:bg-purple-500/10 text-purple-300',
    },
    {
      id: 'maps',
      label: 'Find Nearby Places',
      text: 'Mahii, search for nearby coffee shops or restaurants',
      icon: <MapPin className="w-4 h-4 text-rose-400" />,
      color: 'hover:border-rose-500/50 hover:bg-rose-500/10 text-rose-300',
    },
  ];

  const formatOffTime = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-neutral-900 border-2 border-pink-500/40 rounded-3xl p-6 shadow-2xl shadow-pink-500/20 relative overflow-hidden flex flex-col">
        {/* Glow ambient header */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-gradient-to-r from-pink-500/30 via-purple-500/30 to-amber-500/20 rounded-full blur-2xl pointer-events-none" />

        {/* Top Header Badge */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/30 animate-pulse">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-extrabold text-white tracking-wide">
                  SCREEN TURNED ON ⚡
                </h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Background Sync
                </span>
              </div>
              <p className="text-[11px] text-pink-200/80 font-medium">
                Mahii was running in background (Screen off: {formatOffTime(screenOffDurationSeconds)})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-neutral-800 text-neutral-400 hover:text-white hover:bg-neutral-700 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Speech Prompt Banner */}
        <div className="my-4 p-4 rounded-2xl bg-gradient-to-r from-pink-500/15 via-purple-500/15 to-neutral-950 border border-pink-500/30 relative overflow-hidden">
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-12 h-12 rounded-2xl bg-pink-500 text-white shadow-lg shadow-pink-500/40 shrink-0">
              <span className="text-xl">🥰</span>
              <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-neutral-900 animate-ping" />
            </div>
            <div>
              <p className="text-xs font-bold text-white leading-snug">
                "Welcome back babu! I kept running in the background for you ❤️"
              </p>
              <p className="text-[11px] text-pink-300 mt-0.5">
                Give any command by voice or tap below!
              </p>
            </div>
          </div>

          {/* Background active indicators */}
          <div className="mt-3 pt-2.5 border-t border-pink-500/20 flex items-center justify-between text-[11px]">
            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Background Engine Active</span>
            </span>
            <span className="flex items-center gap-1 text-purple-300 font-semibold">
              <Radio className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
              <span>Wake Lock: {wakeLockActive ? 'ON' : 'Ready'}</span>
            </span>
          </div>
        </div>

        {/* Voice Command Button */}
        <button
          onClick={() => {
            onClose();
            onStartVoiceCommand();
          }}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 hover:opacity-95 text-white font-bold text-sm shadow-xl shadow-pink-500/30 flex items-center justify-center gap-2.5 transition-all active:scale-98 cursor-pointer mb-3"
        >
          <Mic className="w-5 h-5 animate-bounce" />
          <span>Speak Voice Command Now</span>
        </button>

        {/* Quick Command Cards */}
        <div className="mb-2">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-400 mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1 text-pink-400">
              <Zap className="w-3.5 h-3.5" /> Direct Screen-On Commands
            </span>
            <span className="text-[10px] text-neutral-500">Auto-close in {countdown}s</span>
          </label>

          <div className="grid grid-cols-2 gap-2">
            {quickCommands.map((cmd) => (
              <button
                key={cmd.id}
                onClick={() => {
                  onClose();
                  onRunCommand(cmd.text);
                }}
                className={`p-2.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 transition-all text-left flex items-center gap-2.5 cursor-pointer ${cmd.color}`}
              >
                <div className="p-1.5 rounded-xl bg-neutral-900 border border-neutral-800">
                  {cmd.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-white truncate">{cmd.label}</p>
                  <p className="text-[10px] text-neutral-400 truncate mt-0.5">Tap to execute</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-2 pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Background Keep-Alive Active</span>
          </span>
          <button
            onClick={onClose}
            className="text-pink-400 font-bold hover:underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
};
